# CaseMap — AI-Powered Legal Timeline Builder
### Project Report

---

## Content

➤ Abstract  
➤ Existing System  
➤ Drawbacks  
➤ Proposed System  
➤ Advantages  
➤ Requirements  
➤ Architecture Diagram  
➤ Modules  
➤ Module Components  
➤ Class Diagram  
➤ Use Case Diagram  
➤ Activity Diagram  
➤ Queries  

---

## Abstract

CaseMap is an AI-powered legal timeline builder designed to automate and simplify the process of extracting key dates, events, and parties from legal documents. Legal professionals often deal with large volumes of case files, contracts, depositions, and filings, making manual timeline construction tedious, error-prone, and time-consuming.

This application leverages a custom Local Pattern-Matching Engine using regex and advanced heuristics to analyze uploaded legal documents (PDF, DOCX, TXT formats) and automatically extract structured event data — including dates, event titles, descriptions, involved parties, categories, and source quotes without relying on external APIs. The extracted events are rendered on an interactive, zoomable, and filterable visual timeline.

The system also features user authentication with JWT-based security and data export capabilities in CSV, JSON, and PDF formats. Built as a full-stack web application using React, Node.js, Express, and MongoDB, CaseMap provides a modern, private, and efficient solution for legal case timeline management.

---

## Existing System

Currently, legal professionals rely on the following manual and semi-automated methods to build case timelines:

1. **Manual Spreadsheet-Based Timelines**  
   Lawyers and paralegals read through case documents page by page and manually enter dates, events, and notes into Excel or Google Sheets. This is the most common approach in small to medium law firms.

2. **Word Processor Notes**  
   Legal teams use Microsoft Word or similar tools to create chronological summaries by copying key text from documents into a running document, formatting it manually.

3. **Generic Project Management Tools**  
   Some firms repurpose tools like Microsoft Project, Trello, or Asana to track case milestones, but these are not designed for legal document analysis and lack AI-assisted extraction.

4. **Expensive Commercial Legal Software**  
   Enterprise solutions like LexisNexis CaseMap, Relativity, or Trial Director offer timeline features but come with extremely high licensing costs ($500–$5,000+ per user/year), complex setup, and heavy training requirements.

5. **Physical Paper-Based Timelines**  
   In courtroom preparation, attorneys still use physical boards, sticky notes, and printed document summaries to construct visual case timelines during trial preparation.

---

## Drawbacks

The existing systems suffer from the following significant limitations:

1. **Time-Consuming Manual Work**  
   Reading through hundreds or thousands of pages of legal documents and manually extracting dates and events can take days or even weeks for complex cases.

2. **Human Error and Inconsistency**  
   Manual extraction is prone to errors — missed dates, incorrect event associations, and inconsistent formatting across different team members.

3. **No AI or Automation**  
   Traditional tools lack any form of intelligent text analysis. Every event must be identified and typed by a human, regardless of how clearly stated it is in the document.

4. **High Cost of Commercial Solutions**  
   Professional legal timeline software is prohibitively expensive for solo practitioners, small firms, and legal aid organizations, creating a significant access barrier.

5. **Lack of Interactivity**  
   Spreadsheet and word processor timelines are static. They don't offer zooming, filtering, category-based views, or clickable event details.

6. **Poor Collaboration**  
   Paper-based and local spreadsheet timelines are difficult to share, update collaboratively, or export in standardized formats.

7. **No Multi-Format Document Support**  
   Most existing tools require manual text input and don't directly process PDF, DOCX, or TXT files.

8. **No Confidence Scoring**  
   Existing methods provide no indication of how reliable or complete the extracted information is, leaving professionals uncertain about the accuracy of their timelines.

---

## Proposed System

CaseMap addresses all the above drawbacks through a modern, automated full-stack web application with the following workflow:

### How It Works

1. **Document Upload** — Users drag and drop legal documents (PDF, DOCX, TXT) into the application. Up to 50 files (50MB each) can be processed simultaneously.

2. **Automated Extraction** — A custom local text-processing engine analyzes each document using regex and keyword heuristics, automatically extracting:
   - Dates and timeframes
   - Event titles and descriptions
   - Involved parties
   - Event categories (Filing, Hearing, Deposition, Contract, Correspondence)
   - Source quotes from the original text
   - Extraction confidence scores (0–1 scale)

3. **Smart Processing Pipeline** — Documents are chunked with overlapping segments to preserve context. Events are normalized, deduplicated, and stored in MongoDB.

4. **Interactive Timeline** — Extracted events are displayed on a visual, zoomable timeline using vis-timeline. Users can:
   - Click events to view full details
   - Filter by category, date range, or keyword
   - Zoom in/out for different time perspectives

5. **Event Management** — Users can manually add, edit, or delete events to refine the timeline.

6. **Export & Share** — Timelines can be exported as CSV, JSON, or printed as PDF.

7. **User Authentication** — JWT-based registration and login system to protect user data and personalize the experience.

---

## Advantages

1. **Automated Processing** — Eliminates hours of manual document reading. Events are extracted in seconds, entirely locally.

2. **Confidence Scores** — Each extracted event includes a heuristic confidence score, letting users quickly identify which events need verification.

3. **Multi-Format Support** — Directly processes PDF, DOCX, and TXT files without requiring manual text input.

4. **Interactive Visual Timeline** — Unlike static spreadsheets, the timeline is zoomable, filterable, and clickable with rich event details.

5. **Cost-Effective** — Open-source and self-hosted. No expensive per-user licensing fees. Completely free to run offline with zero API costs.

6. **Private & Secure** — Documents stay on your own server. No data is sent to third-party cloud storage. JWT-based authentication protects user accounts.

7. **Batch Processing** — Upload up to 50 documents at once for large-case processing.

8. **Export Flexibility** — Export timelines as CSV (for spreadsheets), JSON (for integration), or PDF (for print/court).

9. **Modern, Responsive UI** — Dark glassmorphism design with micro-animations, works on desktop and mobile browsers.

10. **Easy Deployment** — Simple Node.js application with MongoDB. Can be deployed locally or to any cloud provider.

---

## Requirements

### Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Processor | Intel i3 / AMD Ryzen 3 | Intel i5 / AMD Ryzen 5 or above |
| RAM | 4 GB | 8 GB or above |
| Storage | 500 MB free space | 2 GB+ (for document storage) |
| Display | 1280×720 resolution | 1920×1080 or above |
| Network | None required | Local network / Internet |

### Software Requirements

| Component | Technology | Version |
|-----------|-----------|---------|
| Runtime | Node.js | v18.0+ |
| Package Manager | npm | v9.0+ |
| Database | MongoDB | v6.0+ (local or Atlas) |
| Browser | Chrome / Firefox / Edge | Latest version |
| Operating System | Windows / macOS / Linux | Windows 10+, macOS 12+, Ubuntu 20+ |

### Technology Stack

| Layer | Technologies |
|-------|-------------|
| **Frontend** | React 18, Vite, React Router v6 (react-router-dom), vis-timeline, vis-data, react-dropzone |
| **Backend** | Node.js, Express.js, Mongoose ODM |
| **Database** | MongoDB (local or Atlas) |
| **Extraction Engine** | Local Regex & Heuristic-Based Event Extractor |
| **Authentication** | JWT (jsonwebtoken), bcryptjs |
| **File Processing** | Multer, pdf-parse, mammoth |
| **Styling** | Vanilla CSS (dark glassmorphism theme) |

### API Requirements

| API | Purpose | Key Required |
|-----|---------|-------------|
None. CaseMap's extraction engine runs entirely locally and does not require any external APIs.

---

## Architecture Diagram

The system follows a **three-tier architecture**: the user interacts with the **Frontend** (browser), which talks to the **Backend** (server), which stores data in the **Database**.

```mermaid
graph TD
    subgraph "FRONTEND — What the user sees (React, Port 3000)"
        A["🏠 Home Page<br/>Public landing page with features"]
        B["🔐 Login & Register<br/>User authentication pages"]
        C["📊 Dashboard & Cases List<br/>Overview of all cases"]
        D["📁 Upload Page<br/>Drag & drop documents"]
        E["📅 Timeline Page<br/>Interactive visual timeline"]
        F2["🧭 Navbar<br/>Navigation bar with active links"]
    end

    subgraph "BACKEND — The brain of the app (Node.js + Express, Port 5000)"
        F["🔑 Auth Service<br/>Handles login, register, JWT tokens"]
        G["📂 File Handler<br/>Saves uploaded documents"]
        H["⚙️ Local Engine<br/>Extracts events via heuristics"]
        I["📋 Case & Event API<br/>Create, read, update, delete data"]
    end

    subgraph "DATABASE — Where data is stored (MongoDB)"
        J[("👤 Users")]
        K[("📁 Cases")]
        L[("📄 Documents")]
        M[("📅 Events")]
    end

    A & B --> F
    C & D & E --> I
    D --> G
    G --> H
    F --> J
    I --> K & L & M
    H --> M
```

---

## Modules

The CaseMap application is organized into **6 core modules**, each responsible for a distinct area of functionality:

| # | Module | Description |
|---|--------|-------------|
| 1 | **User Authentication Module** | Handles user registration, login, JWT token generation and verification, password hashing, and session management. |
| 2 | **Document Management Module** | Manages file uploads (drag-and-drop), file storage on disk, MIME type validation, and tracks document processing status (pending → processing → done/error). |
| 3 | **Extraction Engine Module** | Orchestrates the document processing pipeline — text extraction from PDF/DOCX/TXT, intelligent text chunking with overlap, local heuristic extraction for events, and event normalization/deduplication. |
| 4 | **Case & Event Management Module** | Provides CRUD operations for cases and events, supports event filtering (by category, date range, keyword), and handles cascade deletion of related data. |
| 5 | **Timeline Visualization Module** | Renders the interactive visual timeline using vis-timeline, manages zoom/pan controls, event selection, category-based coloring, and data export (CSV, JSON, PDF). |
| 6 | **Application Shell & Routing Module** | Provides the core application structure including client-side routing (React Router), the navigation bar, the landing page, centralized API client helper, global error handling middleware, and the entry point configuration. |

---

## Module Components

MODULE Components

• Extraction Engine Layer:
• Regex, Keyword Heuristics, Pattern Matching Models
• Data Layer:
• MongoDB For Data Storage Of Cases And Events
• File Storage Layer:
• Local Filesystem For Legal Document Storage
• Frontend Components
• UI Framework:
• React For Building User Interfaces
• Visualization:
• Vis-Timeline For Interactive Event Timelines
• User Input Forms:
• Drag And Drop Zones For Document Submission
• Backend Components
• Web Server:
• Express/Node.js For Handling API Requests
• Data Processing Pipeline:
• Text Chunking, Heuristic Inference, Score Calculation
• API Handlers:
• Endpoints For Document Submission And Result Retrieval
• Security & Auth Components
• Token Management:
• JSON Web Tokens For Authenticated Sessions
• Encryption Handlers:
• Bcrypt For Secure Password Hashing

---

## Class Diagram

This diagram shows the **Data Models** in the application based on the actual Mongoose schemas and how they are connected to each other.

```mermaid
classDiagram
    class User {
        +ObjectId _id
        +String fullName
        +String username
        +String email
        +String phone
        +String password
        +Date createdAt
        +Date updatedAt
        +comparePassword()
        +preSave()
    }
    class Case {
        +ObjectId _id
        +String name
        +String description
        +Date createdAt
        +Date updatedAt
        +Virtual documents[]
        +Virtual events[]
    }
    class Document {
        +ObjectId _id
        +ObjectId caseId
        +String filename
        +String filepath
        +String mimeType
        +Number size
        +String status
        +Number pageCount
        +String errorMessage
        +Date createdAt
        +Date updatedAt
    }
    class Event {
        +ObjectId _id
        +ObjectId caseId
        +ObjectId documentId
        +Date date
        +Date endDate
        +String title
        +String description
        +String category
        +Array parties
        +Number confidence
        +String source
        +Boolean isManual
        +Date createdAt
        +Date updatedAt
    }

    User "1" -- "*" Case : Manages
    Case "1" *-- "*" Document : Contains
    Case "1" *-- "*" Event : Contains
    Document "1" -- "*" Event : Extracted From
```

**How to read this:**  
- Each box is a **data model** from the database schema.  
- The **arrows** show how models are logically connected.

---

## Use Case Diagram

```mermaid
graph TB
    subgraph Actors
        Guest(["👤 Guest User"])
        User(["👤 Registered User"])
    end

    subgraph "Authentication System"
        UC1["Register Account"]
        UC2["Login"]
    end

    subgraph "Case Management"
        UC4["Create Case"]
        UC5["View Cases (Dashboard & CaseList)"]
        UC7["Delete Case"]
    end

    subgraph "Document Processing"
        UC8["Upload Documents"]
        UC9["View Processing Status"]
        UC10["Automated Event Extraction"]
    end

    subgraph "Timeline Operations"
        UC11["View Interactive Timeline"]
        UC12["Filter Events"]
        UC13["View Event Details"]
        UC14["Add Manual Event"]
        UC15["Edit Event"]
        UC16["Delete Event"]
        UC17["Export Timeline"]
    end

    Guest --> UC1
    Guest --> UC2

    User --> UC4
    User --> UC5
    User --> UC7
    User --> UC8
    User --> UC9
    User --> UC11
    User --> UC12
    User --> UC13
    User --> UC14
    User --> UC15
    User --> UC16
    User --> UC17

    UC8 -.->|"triggers"| UC10
```

---

## Activity Diagram

This diagram shows the **step-by-step flow** of how the core document extraction feature works in the application.

```mermaid
flowchart TD
    A(["🟢 User opens Upload page"]) --> B["Create a new case name"]
    B --> C["Drag & drop document files"]
    C --> D{"Are files PDF, DOCX, or TXT?"}
    D -->|"❌ No"| E["Show error message"]
    E --> C
    D -->|"✅ Yes"| F["Files uploaded to server"]
    F --> G["File info saved in database"]
    G --> H["Start text processing..."]

    H --> I["Read text from the file"]
    I --> J{"What type of file?"}
    J -->|"PDF"| K["Extract text from PDF"]
    J -->|"Word Doc"| L["Extract text from DOCX"]
    J -->|"Text File"| M["Read text directly"]
    K --> N["Split text into smaller pieces"]
    L --> N
    M --> N

    N --> O["Scan each chunk with local regex engine"]
    O --> P["Engine finds dates, events, and people"]
    P --> Q["Remove duplicate events & fix dates"]
    Q --> R["Save all events to database"]
    R --> S["Mark document as processed ✅"]
    S --> T{"More files to process?"}
    T -->|"Yes"| H
    T -->|"No"| U["Show the timeline to user"]
    U --> V(["🟢 Done!"])

    style A fill:#10b981,color:white
    style V fill:#10b981,color:white
    style E fill:#ef4444,color:white
```

---

## Test Cases

| Test Case ID | Input / Action | Expected Output | Actual Output | Pass/Fail |
|---|---|---|---|---|
| TC01 | Upload a valid legal text document (`.pdf` or `.docx`) | Document saves successfully; status reads 'done' | Document saved, status 'done' | Pass |
| TC02 | Upload a document exceeding the 50MB file size limit | System rejects file and displays "File size exceeds limit" error | Error message displayed | Pass |
| TC03 | Engine scans sentence: *"On January 15, 2024, John Doe filed a motion."* | Extracts: Date (2024-01-15), Name (John Doe), Category (Filing) | Extracted correctly, Confidence 80% | Pass |
| TC04 | Upload a password-protected, encrypted PDF | System prompts for password or throws graceful error | Server timeout and crashes with 500 error | Fail |
| TC05 | Engine extracts a complex written date like *"Jan-Fifteen-Twenty-Twenty-Four"* | Date correctly identified as 2024-01-15 | Date skipped completely, event not generated | Fail |
| TC06 | User manually edits an extracted event on the timeline | Changes are saved to MongoDB and update the UI | Edits saved and UI refreshed | Pass |
| TC07 | Registering a new account with an email that is already taken | System prevents registration; shows "Email in use" | 400 Error: Email in use | Pass |
| TC08 | Exporting a timeline with 10,000+ events to a single PDF | PDF downloads within 15 seconds | Browser page becomes unresponsive and crashes | Fail |

---

## Queries

### Frequently Asked Questions

**Q1: What types of documents can be uploaded?**  
CaseMap supports PDF, DOCX (Microsoft Word), and TXT (plain text) files. Up to 50 files can be uploaded simultaneously, with a maximum file size of 50MB each.

**Q2: How accurate is the automated extraction?**  
The local heuristic engine assigns a confidence score (0.0 to 1.0) based on pattern-matching strength for each extracted event. While fast and 100% offline, complex sentences may require manual review for nuance. The system also deduplicates overlapping extractions to reduce redundancy.

**Q3: Is my data private and secure?**  
Yes. All documents are stored locally on your server. The document text is processed offline, meaning absolute privacy with no data sent to any third-party APIs. User passwords are hashed using bcrypt with 12 rounds of salting. Authentication uses JWT tokens with 7-day expiry.

**Q4: Can I manually add or edit events?**  
Yes. The timeline page includes options to manually create new events, edit existing ones (date, title, description, category, parties), and delete events that are irrelevant.

**Q5: How do I export my timeline?**  
Click the Export button on the timeline page. You can download as:
- **CSV** — for spreadsheet applications (Excel, Google Sheets)
- **JSON** — for data integration with other tools
- **Print/PDF** — uses the browser's print function for PDF generation

**Q6: Do I need an API key to run this?**  
No! CaseMap has been updated to use a custom local regex and heuristic-based extractor. It runs completely offline and does not require any external API keys to function.

**Q7: Can multiple users work on the same case?**  
Currently, cases are shared across all users. Any authenticated user can view and edit any case.

**Q8: What happens if document processing fails?**  
If the extraction process fails for a document, its status is marked as "error" in the database. You can re-upload the document to retry processing. The error details are logged in the server console.

**Q9: What database does CaseMap use?**  
CaseMap uses MongoDB, which can run locally (via MongoDB Community Server) or in the cloud (via MongoDB Atlas free tier). The connection string is configured in `server/.env` as `MONGODB_URI`.
